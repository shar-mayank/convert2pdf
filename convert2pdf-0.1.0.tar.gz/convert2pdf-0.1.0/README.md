# convert2pdf

A command-line tool to easily convert between DOCX/PPTX and PDF formats.

## Installation

```bash
brew install convert2pdf
```

Note: This tool depends on LibreOffice. If not already installed, you'll need to run:

```bash
brew install --cask libreoffice
```