#compdef convert2pdf

_arguments \
  '(-h --help)'{-h,--help}'[Show help message]' \
  '(-v --version)'{-v,--version}'[Show version information]' \
  '*:file:_files'